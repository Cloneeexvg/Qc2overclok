#!/sbin/sh

. /tmp/backuptool.functions

list_files() {
cat <<EOF
/system/addon.d/bootanimation.sh
/system/media/bootanimation.zip
END
EOF
}

case "$1" in
backup)
  mount -t ext4 /dev/block/system /system -o rw,discard

  list_files | while read FILE; do
    backup_file "$FILE"
  done

  umount /system
;;
restore)
  mount -t ext4 /dev/block/system /system -o rw,discard

  list_files | while read FILE; do
    R=""
    [ -n "$REPLACEMENT" ] && R="$REPLACEMENT"
    [ -f "$C/$FILE" ] && restore_file "$FILE" "$R"
  done

  umount /system
;;
pre-backup)
# Stub
;;
post-backup)
# Stub
;;
pre-restore)
# Stub
;;
post-restore)
# Stub
;;
esac
